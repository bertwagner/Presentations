USE StackOverflowDemo;
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.USP_SelectComparableUserData'))
   exec('CREATE PROCEDURE dbo.USP_SelectComparableUserData AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE dbo.USP_SelectComparableUserData
	@UserIds varchar(8000)
AS
BEGIN
DECLARE	
	@DisplayNames varchar(8000),
	@Ages varchar(8000),
	@LastAccessDates varchar(8000),
	@UpVotes varchar(8000),
	@DownVotes varchar(8000),
	@Repuation varchar(8000),
	@MaxAge int = 0,
	@MaxLastAccessDate datetime = '1900-01-01',
	@MaxUpVotes int=0,
	@MaxDownVotes int=0,
	@MaxReputation int =0,
	@ColumnCount int = 1

SELECT 
	@DisplayNames = COALESCE(@DisplayNames + ', ','') + '''' + DisplayName + ''' as C'+CAST(@ColumnCount AS VARCHAR(10)), 
	@Ages = COALESCE(@Ages + ', ','') + '''' + ISNULL(CAST(Age AS VARCHAR(4)),'')  + ''' as C'+CAST(@ColumnCount AS VARCHAR(10)),
	@MaxAge = CASE WHEN Age > @MaxAge THEN Age ELSE @MaxAge END,
	@LastAccessDates = COALESCE(@LastAccessDates + ', ','') + '''' + CAST(LastAccessDate AS VARCHAR(20)) + ''' as C'+CAST(@ColumnCount AS VARCHAR(10)),
	@MaxLastAccessDate = CASE WHEN LastAccessDate > @MaxLastAccessDate THEN LastAccessDate ELSE @MaxLastAccessDate END,
	@UpVotes = COALESCE(@UpVotes + ', ','') + '''' + CAST(UpVotes AS VARCHAR(10)) + ''' as C'+CAST(@ColumnCount AS VARCHAR(10)), 
	@MaxUpVotes = CASE WHEN UpVotes > @MaxUpVotes THEN UpVotes ELSE @MaxUpVotes END,
	@DownVotes = COALESCE(@DownVotes + ', ','') + '''' + CAST(DownVotes AS VARCHAR(10)) + ''' as C'+CAST(@ColumnCount AS VARCHAR(10)),
	@MaxDownVotes = CASE WHEN DownVotes > @MaxDownVotes THEN DownVotes ELSE @MaxDownVotes END,
	@Repuation = COALESCE(@Repuation + ', ','') + '''' + CAST(Reputation AS VARCHAR(10)) + ''' as C'+CAST(@ColumnCount AS VARCHAR(10)),
	@MaxReputation = CASE WHEN Reputation > @MaxReputation THEN Reputation ELSE @MaxReputation END,
	@ColumnCount = @ColumnCount+1 
FROM [dbo].[Users]
WHERE 
	Id IN (SELECT value FROM STRING_SPLIT(@UserIds,',')) 

DECLARE @FinalQuery nvarchar(max) = 
	'SELECT ''' + CAST(@ColumnCount-1 AS VARCHAR(10)) + ''' AS ColumnCount, '''' AS MaxValue, ''Name'' AS C0,' + @DisplayNames 
	+ ' UNION ALL SELECT ''' + CAST(@ColumnCount-1 AS VARCHAR(10)) + ''' AS ColumnCount, ''' +CAST(@MaxAge AS VARCHAR(3))+''' AS MaxValue, ''Years of Wisdom'' AS C0,' + @Ages
	+ ' UNION ALL SELECT ''' + CAST(@ColumnCount-1 AS VARCHAR(10)) + ''' AS ColumnCount, ''' +CAST(@MaxLastAccessDate AS VARCHAR(20))+''' AS MaxValue, ''LastAccessDate'' as C0,' + @LastAccessDates 
	+ ' UNION ALL SELECT ''' + CAST(@ColumnCount-1 AS VARCHAR(10)) + ''' AS ColumnCount, ''' +CAST(@MaxUpVotes AS VARCHAR(10))+''' AS MaxValue, ''UpVotes'' as C0,' + @UpVotes 
	+ ' UNION ALL SELECT ''' + CAST(@ColumnCount-1 AS VARCHAR(10)) + ''' AS ColumnCount, ''' +CAST(@MaxDownVotes AS VARCHAR(10))+''' AS MaxValue, ''DownVotes'' AS C0,' + @DownVotes 
	+ ' UNION ALL SELECT ''' + CAST(@ColumnCount-1 AS VARCHAR(10)) + ''' AS ColumnCount, ''' +CAST(@MaxReputation AS VARCHAR(10))+''' AS MaxValue, ''Reputation'' as C0,' + @Repuation 

EXEC(@FinalQuery)

END
GO

--Execute the USP with some sample user ids
EXEC dbo.USP_SelectComparableUserData '13,24,25,37'--,39,48,51,58,67,71'
GO
