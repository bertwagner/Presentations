-- Grab the StackOverflow data dump from Brent Ozar: https://www.brentozar.com/archive/2015/10/how-to-download-the-stack-overflow-database-via-bittorrent/

-- This script reduces the size of the StackOverflow database because it is too big to run on my laptop :'(
-- It keeps a subset of the data, including data for UserId=2908419...which is my StackOverflow account.
-- If you're computer can handle the full dataset, then you can just run the statements at the end to create indexes.


CREATE DATABASE StackOverflowDemo;
GO

USE StackOverflowDemo;
GO


SELECT TOP 1000000 * INTO StackOverflowDemo.dbo.Posts from StackOverflow.dbo.Posts ORDER BY Id DESC;
GO
INSERT INTO StackOverflowDemo.dbo.Posts SELECT * FROM StackOverflow.dbo.Posts 
WHERE ParentId IN (SELECT Id FROM StackOverflowDemo.dbo.Posts);
GO
-- Delete duplicates
WITH CTE AS(
   SELECT Id, RN = ROW_NUMBER()OVER(PARTITION BY Id ORDER BY Id)
   FROM StackOverflowDemo.dbo.Posts
)
DELETE FROM CTE WHERE RN > 1;
GO


SELECT * INTO StackOverflowDemo.dbo.Users FROM StackOverflow.dbo.Users WHERE Id IN (SELECT OwnerUserId FROM StackOverflowDemo.dbo.Posts);
GO


SELECT * INTO StackOverflowDemo.dbo.Votes FROM StackOverflow.dbo.Votes WHERE PostId IN (SELECT Id FROM StackOverflowDemo.dbo.Posts);
GO
INSERT INTO StackOverflowDemo.dbo.Votes SELECT * FROM StackOverflow.dbo.Votes WHERE UserId IN (SELECT Id FROM StackOverflowDemo.dbo.Users);
GO
-- Delete duplicates
WITH CTE AS(
   SELECT Id, RN = ROW_NUMBER()OVER(PARTITION BY Id ORDER BY Id)
   FROM StackOverflowDemo.dbo.Votes
)
DELETE FROM CTE WHERE RN > 1;
GO


SELECT * INTO StackOverflowDemo.dbo.Comments FROM StackOverflow.dbo.Comments WHERE PostId IN (SELECT Id FROM StackOverflowDemo.dbo.Posts);
GO
INSERT INTO StackOverflowDemo.dbo.Comments SELECT * FROM StackOverflow.dbo.Comments WHERE UserId IN (SELECT Id FROM StackOverflowDemo.dbo.Users);
GO
-- Delete duplicates
;WITH CTE AS(
   SELECT Id, RN = ROW_NUMBER()OVER(PARTITION BY Id ORDER BY Id)
   FROM StackOverflowDemo.dbo.Comments
)
DELETE FROM CTE WHERE RN > 1;
GO

SELECT * INTO StackOverflowDemo.dbo.Badges FROM StackOverflow.dbo.Badges WHERE UserId IN (SELECT Id FROM StackOverflowDemo.dbo.Users);
GO





-- Create PKs and indexes
ALTER TABLE StackOverflowDemo.dbo.Users ADD  CONSTRAINT [PK_UsersDemo_Id] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO

CREATE NONCLUSTERED INDEX IX_Location ON StackOverflowDemo.dbo.Users(Location)
GO

ALTER TABLE StackOverflowDemo.dbo.Votes ADD  CONSTRAINT [PK_VotesDemo__Id] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO


ALTER TABLE StackOverflowDemo.dbo.Comments ADD  CONSTRAINT [PK_CommentsDemo__Id] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO


ALTER TABLE StackOverflowDemo.dbo.Badges ADD  CONSTRAINT [PK_BadgesDemo__Id] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON);
GO

CREATE NONCLUSTERED INDEX IX_AcceptedAnswerId ON StackOverflowDemo.dbo.Posts(AcceptedAnswerId);
GO
CREATE NONCLUSTERED INDEX IX_AnswerCount ON StackOverflowDemo.dbo.Posts(AnswerCount);
GO

CREATE CLUSTERED INDEX CL_Id ON StackOverflowDemo.dbo.Users (Id);
GO



