SELECT 
	*
FROM 
	-- This is the default database for your SSRS Server
	[ReportServer].[dbo].[ExecutionLog]
