USE StackOverflowDemo;
GO
-- These two queries are the same except for the Location in the WHERE clause
-- If we include the actual execution plan, we'll see that although the queries look the same,
--		two different query plans get used due to the difference in the number of results each query returns.

SET STATISTICS IO ON
SET STATISTICS TIME ON

SELECT DISTINCT
	Id, Location, DisplayName
FROM 
	dbo.Users
WHERE 
	Location = 'China'
GO

SELECT DISTINCT
	Id, Location, DisplayName
FROM 
	dbo.Users
WHERE 
	Location = 'India'
GO

--If we parameterize these queries, you'll notice that both queries will run with the same plan
-- (the clustered index scan plan for India doesn't get ran)

DECLARE @Location varchar(100) = 'China'
SELECT DISTINCT
	Id, Location, DisplayName
FROM 
	dbo.Users
WHERE 
	Location = @Location
GO

DECLARE @Location varchar(100) = 'India'
SELECT DISTINCT
	Id, Location, DisplayName
FROM 
	dbo.Users
WHERE 
	Location = @Location
GO

-- If we create a procedure...
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.USP_SelectUsersByLocation'))
   exec('CREATE PROCEDURE dbo.USP_SelectUsersByLocation AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE dbo.USP_SelectUsersByLocation
	@Location varchar(100)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT DISTINCT
		Id, Location, DisplayName
	FROM 
		dbo.Users
	WHERE 
		Location = @Location
END

-- ... the same plan caching occurs
EXEC dbo.USP_SelectUsersByLocation 'China'
EXEC dbo.USP_SelectUsersByLocation 'India'

-- If we clear the cache
DBCC FREEPROCCACHE;
GO
-- And run India first, we see both executions get the Clustered index scan plan
EXEC dbo.USP_SelectUsersByLocation 'India'
GO
EXEC dbo.USP_SelectUsersByLocation 'China'
GO

-- Solutions?
-- 1) Call the USP WITH RECOMPILE
EXEC dbo.USP_SelectUsersByLocation 'China'  WITH RECOMPILE
GO
EXEC dbo.USP_SelectUsersByLocation 'India' WITH RECOMPILE
GO

-- 2) Alter the stored procedure to use OPTION (RECOMPILE)
ALTER PROCEDURE dbo.USP_SelectUsersByLocation
	@Location varchar(100)
AS
BEGIN
	SELECT DISTINCT
		Id, Location, DisplayName
	FROM 
		dbo.Users
	WHERE 
		Location = @Location
	OPTION (RECOMPILE)
END
GO

EXEC dbo.USP_SelectUsersByLocation 'China'
GO
EXEC dbo.USP_SelectUsersByLocation 'India'
GO

-- 3) Alter the stored procedure to use OPTIMIZE FOR.  Pick a value for @Location that will work well for both queries where 
--    the parameter is India or China.  In this case the China query plan with Index Seeks runs faster for India than vice versa.
ALTER PROCEDURE dbo.USP_SelectUsersByLocation
	@Location varchar(100)
AS
BEGIN
	SELECT DISTINCT
		Id, Location, DisplayName
	FROM 
		dbo.Users
	WHERE 
		Location = @Location
	OPTION (OPTIMIZE FOR (@Location='China'));
END
GO

EXEC dbo.USP_SelectUsersByLocation 'India'
GO
EXEC dbo.USP_SelectUsersByLocation 'China'
GO
 