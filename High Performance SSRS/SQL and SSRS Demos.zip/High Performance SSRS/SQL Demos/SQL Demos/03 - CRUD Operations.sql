USE StackOverflowDemo;
GO

-- Create our table that will store favorite posts by user
DROP TABLE IF EXISTS dbo.Favorites
CREATE TABLE dbo.Favorites
(
	Id int IDENTITY(1,1) PRIMARY KEY,
	UserId int NOT NULL,
	PostId int NOT NULL
)

-- Add some favorite posts for our user
INSERT INTO dbo.Favorites (UserId, PostId) VALUES (2908419,35320653)
INSERT INTO dbo.Favorites (UserId, PostId) VALUES (2908419,35385751)

--Let's look at our table
SELECT * FROM dbo.Favorites


-- Create the procedure to show a user's favorite posts
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.USP_SelectUsersFavorites'))
   exec('CREATE PROCEDURE dbo.USP_SelectUsersFavorites AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE dbo.USP_SelectUsersFavorites
	@UserId int
AS
BEGIN
SELECT
	f.Id,
	f.PostId,
	p.Title,
	LEFT(p.Body, CASE WHEN LEN(p.Body) >200 THEN 200 ELSE LEN(p.Body) END) + '...' AS Body
FROM
	dbo.Favorites f
	INNER JOIN dbo.Posts p
		ON f.PostId = p.Id
WHERE
	f.UserId = @UserId
END
GO

-- Create the procedure to show related posts that the user might like
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.USP_SelectRelatedPosts'))
   exec('CREATE PROCEDURE dbo.USP_SelectRelatedPosts AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE dbo.USP_SelectRelatedPosts
	@UserId int
AS
BEGIN
	-- We limit related posts to 4 hardcoded PostIds that haven't been marked as favorites yet
SELECT
	p.Id as PostId,
	p.Title,
	LEFT(p.Body, CASE WHEN LEN(p.Body) >200 THEN 200 ELSE LEN(p.Body) END) + '...' AS Body
FROM
	dbo.Posts p
	LEFT JOIN dbo.Favorites f
		ON p.Id = f.PostId
		AND f.UserId = @UserId
WHERE 
	p.Id IN (35320653, 35427378, 35731849, 35385751)
	AND f.PostId IS NULL
END			
GO

-- Create the procedure to mark a post as a favorite
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.USP_InsertPostIntoFavorites'))
   exec('CREATE PROCEDURE dbo.USP_InsertPostIntoFavorites AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE dbo.USP_InsertPostIntoFavorites
	@UserId int,
	@PostId int,
	@Action varchar(10)
AS
BEGIN
	IF @Action = 'INSERT' 
	BEGIN
		INSERT INTO dbo.Favorites (UserId, PostId) VALUES (@UserId, @PostId)
	END
END
GO

-- Create the procedure to unmark a post as a favorite
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.USP_DeletePostFromFavorites'))
   exec('CREATE PROCEDURE dbo.USP_DeletePostFromFavorites AS BEGIN SET NOCOUNT ON; END')
GO
ALTER PROCEDURE dbo.USP_DeletePostFromFavorites
	@UserId int,
	@PostId int,
	@Action varchar(10)
AS
BEGIN
	IF @Action = 'DELETE' 
	BEGIN
		DELETE FROM dbo.Favorites WHERE UserId = @UserId AND PostId = @PostId
	END
END
GO
	 