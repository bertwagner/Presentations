This solution was built using SSDT 2017

If you need this solution to work in older versions of SSDT, you might be able to get away with following the advise here:
https://stackoverflow.com/questions/15310924/vs-2012-solution-and-projects-incompatible-with-vs-2010
